﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoonExecutorBetterUI
{
    internal class Information
    {
        public static void DiscordInvite()
        {
            System.Diagnostics.Process.Start("https://discord.gg/hKSMgfGd");
        }
    }
}
