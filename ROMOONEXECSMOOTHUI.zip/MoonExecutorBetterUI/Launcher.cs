﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoonExecutorBetterUI
{
    public partial class Launcher : Form
    {
        public Launcher()
        {
            InitializeComponent();
        }

        private void siticoneButton3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void siticoneButton4_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void siticoneButton2_Click(object sender, EventArgs e)
        {
            Information.DiscordInvite();
        }

        private void siticoneButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoaderUI loaderui = new LoaderUI();
            loaderui.Show();
        }

        private void siticoneButton1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            LoaderUI loaderui = new LoaderUI();
            loaderui.Show();
        }
    }
}
