﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoonExecutorBetterUI
{
    public partial class LoaderUI : Form
    {
        public LoaderUI()
        {
            InitializeComponent();
        }

        private void LoaderUI_Load(object sender, EventArgs e)
        {

        }

        private void siticoneButton3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private async void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            await Task.Delay(1000);
            WebClient updatecheck = new WebClient();
            panel3.Width = 120;
            label1.Text = ("Checking for Updates...");
            await Task.Delay(1000);
            if (!updatecheck.DownloadString("https://raw.githubusercontent.com/Miloga0000/MoonExecutorUpdate/main/UpdateCheck").Contains("1.0"))
            {
                label1.Text = ("You do not have the Correct Version! Please Update.");
                MessageBox.Show("You do not have the Correct Version for Moon Executor. Would you like to Join the Discord Server?", "Moon");
                Information.DiscordInvite();
                await Task.Delay(1000);
                Application.Exit();
            }
            else
            {
                panel3.Width = 210;
                label1.Text = ("Checking for Patch");
                await Task.Delay(1000);
                WebClient patchcheck = new WebClient();
                if (!patchcheck.DownloadString("https://raw.githubusercontent.com/Miloga0000/MoonExecutorUpdate/main/PatchCheck").Contains("notpatched"))
                {
                    MessageBox.Show("Moon Executor is patched right now. If you would like, you can join the Discord Server for latest updates / announcments.", "Moon");
                    Information.DiscordInvite();
                    await Task.Delay(1000);
                    Application.Exit();
                }
                else
                {
                    panel3.Width = 310;
                    label1.Text = ("Loading Moon Executor...");
                    await Task.Delay(1500);
                    panel3.Width = 532;
                    await Task.Delay(1500);
                    this.Hide();
                    MoonExec moonexec = new MoonExec();
                    moonexec.Show();
                }
            }
        }
    }
}
